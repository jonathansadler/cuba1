from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(Client)


admin.site.register(DeadPerson)
admin.site.register(Relative)

admin.site.register(Activity)

admin.site.register(ActivityType)

admin.site.register(Charge)

admin.site.register(ActivityCharge)

admin.site.register(Invoice)

admin.site.register(InvoiceItem)






"""
admin.site.register(Client)
"""

"""
admin.site.register(DeadPerson)
admin.site.register(Relative)

admin.site.register(Activity)

admin.site.register(ActivityType)

"""


